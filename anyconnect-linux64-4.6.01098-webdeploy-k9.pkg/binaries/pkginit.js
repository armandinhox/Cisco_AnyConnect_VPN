/**************************************************************************
*       Copyright (c) 2017, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    pkgint.js
*
***************************************************************************
*
* Linux 64 init file for AnyConnect Secure Mobility Client WebLaunch.
*
***************************************************************************/
var supportedCpu = "AMD64";
var packageConnectImg = new Image(238, 53);
packageConnectImg.src = "img/gnome-notification-area.png";
var packageConnectMsg = 'If you have GTK 2.10.0 or later, look for the icon in the notification area:<br><img src="' 
   + packageConnectImg.src + '" width ="' + packageConnectImg.width + '" height="' + packageConnectImg.height + '"><br>';
function loadPackage ()
{
    if (IsLinux64)
    {
        ToggleHelpButtonEnable(true);
        // Magic state 20 == launch Java applet
        Start(0);
    }
    else
    {
        // Magic state -60 == go to the next installed package
        Start(-60);
    }
}
var packageInstaller = "anyconnect-linux64-4.6.01098-core-vpn-webdeploy-k9.sh";
var packageVersion = "4,6,01098";
